# Solar Battery Monitoring & Automatic Protection — Hackathon Prototype

This starter prototype contains:
- `dashboard.html`: a browser-based demo dashboard with simulated readings and buttons to trigger demo fault conditions.
- `esp32_solar_monitor.ino`: starter ESP32 firmware for a **12 V lead-acid prototype** using a voltage divider, DS18B20 temperature sensor, optional ACS712 current sensor, and a relay module to disconnect the DC lamp load.
- `WIRING_AND_TESTING.md`: assumptions, wiring notes, and safety checklist.

## Important: demo vs physical hardware
The HTML dashboard is a simulation; it does not connect to real hardware.
The ESP32 sketch is starter code and must be calibrated and tested with a multimeter before connecting a battery or load. It has not been validated against your exact components.

## Suggested demo flow
1. Open `dashboard.html` in a browser.
2. Click **Simulate low battery**, **Simulate high temperature**, and **Reset demo** to demonstrate status changes and load cut-off logic.
3. For a physical prototype, assemble the low-voltage circuit with a fuse, suitable charge controller, and correctly rated DC switching device. Test with a current-limited bench supply or safe test load first.
4. Show the firmware repository/files and explain that the dashboard HTML is the UI simulation while hardware integration is the next validation step.

## Default firmware assumptions
- Battery: 12 V lead-acid (prototype assumption only).
- Low-voltage cut-off: 11.8 V.
- Reconnect threshold: 12.6 V (hysteresis avoids rapid relay switching).
- Temperature cut-off: 55 °C; reconnect below 45 °C.
- Current sensor: ACS712 analogue output, optional.
- DS18B20 temperature sensor on GPIO 4.
- Battery voltage divider: 100 kΩ from battery positive to ADC node and 27 kΩ from ADC node to ground.
- Load relay control on GPIO 26. Firmware assumes `HIGH` energizes the relay and that the load is wired through the relay's **normally-open (NO)** contact, so the load is disconnected when the relay is de-energized. Verify your relay module's behavior before wiring.

These thresholds are example values for a prototype, not universal battery specifications. Follow the battery manufacturer's limits and your charge controller's instructions. Do not rely on Wi-Fi, the dashboard, or ESP32 firmware as the only battery protection layer.
